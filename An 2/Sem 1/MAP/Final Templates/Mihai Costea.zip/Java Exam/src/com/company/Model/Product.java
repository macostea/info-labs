package com.company.Model;

/**
 * Created by C.Mihai on 01/02/14.
 */
public class Product {
    public String servingType;
    public int price;
}
