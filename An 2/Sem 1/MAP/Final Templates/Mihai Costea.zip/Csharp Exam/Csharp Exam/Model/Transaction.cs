﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Exam.Model
{
    class Transaction
    {
        public Property property { get; set; }
        public int year { get; set; }
        public int month { get; set; }
    }
}
